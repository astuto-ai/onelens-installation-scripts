# Version History

| Version | Short Description | Image Tag Version |
|---------|------------------|------------------|
| 0.0.1-beta.3   | Onelens agent is a deployment | 0.0.1-beta.3 |
| 0.0.1-beta.4   | Support for steampipe is removed | 0.0.1-beta.4 |
| 0.0.1-beta.10   | New built-in cron job and other fixes | 0.0.1-beta.10 |
| 0.1.0-beta.1 | Onelens agent in now a cronjob |
|  0.1.1-beta.2 | Add secrets, clusterrole and clusterrolebindings |
|0.1.1-beta.3 | Support for ImagePull Secrets | 
