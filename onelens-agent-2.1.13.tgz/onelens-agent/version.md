# Version History

| Version | Short Description | Image Tag Version |
|---------|------------------|------------------|
| 0.0.1-beta.3   | First internal beta release | 0.0.1-beta.3 |
| 0.0.1-beta.4   | Support for steampipe is removed | 0.0.1-beta.4 |
| 0.0.1-beta.5   | Default values changes | 0.0.1-beta.5 |
| 0.0.1-beta.10   | New built-in cron job and other fixes | 0.0.1-beta.10 |
| 0.1.1-beta.2   | Upgrade to onelens-agent-base chart v0.1.1-beta.2      |
| 0.1.1-beta.3 | Use the custom prometheus scrape config |0.1.1-beta.3 | 
| 0.1.1-beta.4 | Support for imagePullSecrets | 0.1.1-beta.4 |
| 1.1.0 | Versioning Changes | 1.1.0 |
| 1.1.0 | Versioning Changes | 1.1.0 |
| v1.5.0 | Versioning Changes | v1.5.0 |
| v1.1.0 | Versioning Changes | v1.1.0 |
| v1.2.0 | Skipped | v1.2.0 |
| v1.3.0 | Skipped | v1.3.0 |
| v1.4.0 | Skipped | v1.4.0 |
| v1.4.1 | Skipped | v1.4.1 |
| v1.5.0 | Right size the reqs and limits of agent based on available max usage data | v1.5.0 |
| v1.6.0 | set resources for ksm , gateway , reloader | v1.6.0 |
| v1.7.0 | Agent Image changes | v1.7.0 |
| v1.8.0 | Adaptive KSM and Pushgateway Resource config | v1.8.0 |
| v1.9.0 | Implement Principle of least privilege | v1.9.0 |
| v2.0.0 | Multi-cloud support: Add Azure AKS installation support | v2.0.0 |
| v2.0.1 | Azure AKS support improvements and bug fixes | v2.0.1 |
