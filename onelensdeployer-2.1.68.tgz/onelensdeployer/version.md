#RELEASE-NOTE
#0.1.0 - Very stable version
#0.2.0 - Changes the name of the cronjob
#1.1.0 - Versioning bumpup for consistency
#1.2.0 - Skipped
#1.3.0 - EBS tags and Encryption
#1.4.0 - change prometheus memory requests
#1.4.1 - change calculation of pods
#1.5.0 - change resources config of agent
#1.6.0 - set resources for ksm , gateway , reloader
#1.7.0 - API's changes
#1.8.0 - Adaptive KSM and Pushgateway Resource config
#1.9.0 - Implement Principle of least privilege
#2.0.0 - Multi-cloud support: Add Azure AKS installation support
#2.0.1 - Azure AKS support improvements and bug fixes